<template>
  <div class="app">
    <router-view />
  </div>
</template>

<style lang="stylus">
@import '~vue-googlemaps/dist/vue-googlemaps.css'
@import '../styles/main'
</style>
