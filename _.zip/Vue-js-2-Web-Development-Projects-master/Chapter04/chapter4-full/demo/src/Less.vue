<template>
  <article class="article">
    <h3 class="title">Title</h3>
  </article>
</template>

<style lang="less" scoped>
.article {
  .title {
    border-bottom: solid 3px fade(red, 20%);
  }
}
</style>
