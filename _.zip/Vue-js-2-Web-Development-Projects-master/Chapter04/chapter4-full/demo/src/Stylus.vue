<template>
  <article class="article">
    <h3 class="title">Title</h3>
  </article>
</template>

<style lang="stylus" scoped>
.article
  .title
    border-bottom: solid 3px rgba(red, .2)
</style>
