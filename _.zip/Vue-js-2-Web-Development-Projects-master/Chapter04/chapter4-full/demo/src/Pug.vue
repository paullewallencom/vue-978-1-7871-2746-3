<template lang="pug">
ul.movies
  li.movie Star Wars
  li.movie Blade Runner
</template>
