import Vue from 'vue'
import Http from './utils/http'

Vue.use(Http)
