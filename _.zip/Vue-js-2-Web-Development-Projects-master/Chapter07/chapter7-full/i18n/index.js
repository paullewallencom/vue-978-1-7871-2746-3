export default [
  'en',
  'fr',
  'es',
  'de',
]
