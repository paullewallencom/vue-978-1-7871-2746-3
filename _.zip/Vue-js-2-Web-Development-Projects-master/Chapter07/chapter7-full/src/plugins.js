import Vue from 'vue'
import Http from './utils/http'
import VueI18n from 'vue-i18n'

Vue.use(Http)
Vue.use(VueI18n)
